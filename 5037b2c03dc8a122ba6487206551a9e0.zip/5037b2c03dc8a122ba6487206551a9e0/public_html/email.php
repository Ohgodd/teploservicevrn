<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Получаем данные от React (он шлет JSON)

$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    $name = trim($data['name']);
    $phone = trim($data['phoneNumber']);
    $desc = trim($data['desc']);

    // Настройки почты
    $to = "teploservisvrn@rambler.ru";
    $subject = "🔥 Новая заявка с сайта";
    
    // Тело письма
    $message = "Имя: $name\nТелефон: $phone\nПодробное описание: $desc";
    
    // Заголовки (чтобы не улетало в спам и кодировка была норм)
    $headers = "From no-reply@teploservicevrn.ru\r\n";
    $headers .= "Content-type: text/plain; charset=utf-8\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Отправка
    if (mail($to, $subject, $message, $headers)) {
        echo json_encode(["status" => "success", "debug" => "Mail function returned TRUE"]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Mail server error"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "No data"]);
}
?>